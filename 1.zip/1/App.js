import { StyleSheet, Text, View, Image } from 'react-native';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={{uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6F-2rGKrHejQ-bgo1Ozd49DO2OVSl-xezxuVdpCEML4B_lUhijQFJHmF0Nk24ubp-H7Ih1yIojYYB4YY2sqzKb-09MEYH-rBn0NrM8Q&s=10'}} />
      <Text style={styles.name}>
        Taisalmas Sultan
      </Text>
      <Text style={styles.group}>CS-401</Text>
      <AssetExample />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  name: {
    marginTop: 10,
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  group: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
    alignSelf: 'center',
  }
});
