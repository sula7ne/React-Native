import { Text, View, StyleSheet } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.item}>8 700 294 6159</Text>
      <Text style={styles.item}>taisalmas14@gmail.com</Text>
      <Text style={styles.item}>taisalmas14@gmail.com</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginTop: 40,
    alignItems: 'center',
    padding: 24,
    rowGap: 20,
  },
  item: {
    fontSize: 14,
    fontWeight: 'bold',
  },
});
